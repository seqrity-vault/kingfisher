Link to release:
https://github.com/mongodb/kingfisher/releases/download/v1.19.0/kingfisher-linux-x64.tgz

Create a liux apalpine based dockerfile to run above tools.
Make sure that evey thime we buildm, the lates version should be fetcvhed..current the baove link has latest release

but version will keepchanigng.


Shld be linux based 

binary sould exist in /app

